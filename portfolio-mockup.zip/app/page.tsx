import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Github, Linkedin, Mail, ExternalLink, Code, Database, Zap, Globe } from "lucide-react"

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-gray-950/80 backdrop-blur-md border-b border-gray-800 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="text-xl font-bold bg-gradient-to-r from-lime-400 to-cyan-400 bg-clip-text text-transparent">
              CR
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#inicio" className="hover:text-lime-400 transition-colors">
                Inicio
              </a>
              <a href="#proyectos" className="hover:text-lime-400 transition-colors">
                Proyectos
              </a>
              <a href="#habilidades" className="hover:text-lime-400 transition-colors">
                Habilidades
              </a>
              <a href="#contacto" className="hover:text-lime-400 transition-colors">
                Contacto
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="inicio" className="pt-20 pb-16 px-6">
        <div className="container mx-auto max-w-4xl text-center">
          <div className="mb-8">
            <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-r from-lime-400 to-cyan-400 p-1">
              <div className="w-full h-full rounded-full bg-gray-950 flex items-center justify-center">
                <span className="text-4xl font-bold bg-gradient-to-r from-lime-400 to-cyan-400 bg-clip-text text-transparent">
                  CR
                </span>
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-4">
              <span className="bg-gradient-to-r from-lime-400 to-cyan-400 bg-clip-text text-transparent">
                Cristopher Andres
              </span>
              <br />
              Rivera Concha
            </h1>
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
              Me apasiona la música, la automatización con microcontroladores, ver películas y usar la
              <span className="text-lime-400"> tecnología para solucionar problemas</span> y mejorar procesos. Mi
              motivación es crear herramientas que faciliten el trabajo diario y contribuyan al crecimiento de las
              organizaciones.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-gradient-to-r from-lime-400 to-cyan-400 text-gray-950 hover:from-lime-500 hover:to-cyan-500 font-semibold">
                Ver Proyectos
              </Button>
              <Button
                variant="outline"
                className="border-lime-400 text-lime-400 hover:bg-lime-400 hover:text-gray-950 bg-transparent"
              >
                Descargar CV
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="proyectos" className="py-16 px-6 bg-gray-900/50">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="bg-gradient-to-r from-lime-400 to-cyan-400 bg-clip-text text-transparent">Proyectos</span>
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Featured Project */}
            <Card className="md:col-span-2 bg-gray-800/50 border-gray-700 hover:border-lime-400/50 transition-all duration-300 group">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Database className="w-6 h-6 text-lime-400" />
                  <Badge variant="secondary" className="bg-lime-400/20 text-lime-400">
                    Destacado
                  </Badge>
                </div>
                <CardTitle className="text-xl group-hover:text-lime-400 transition-colors">
                  Sistema de Ingreso de Personal
                </CardTitle>
                <CardDescription className="text-gray-300">
                  Interfaz web completa para gestionar el proceso de ingreso de nuevos empleados
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 mb-4">
                  Una solución integral que permite registrar nuevos ingresos, hacer seguimiento de documentos,
                  gestionar etapas del proceso y enviar notificaciones automáticas por correo.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="outline" className="border-cyan-400 text-cyan-400">
                    Django
                  </Badge>
                  <Badge variant="outline" className="border-cyan-400 text-cyan-400">
                    JavaScript
                  </Badge>
                  <Badge variant="outline" className="border-cyan-400 text-cyan-400">
                    HTML/CSS
                  </Badge>
                  <Badge variant="outline" className="border-cyan-400 text-cyan-400">
                    Automatización
                  </Badge>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-lime-400 text-lime-400 hover:bg-lime-400 hover:text-gray-950 bg-transparent"
                  >
                    <Github className="w-4 h-4 mr-2" />
                    Código
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-gray-950 bg-transparent"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Demo
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Other Projects */}
            <Card className="bg-gray-800/50 border-gray-700 hover:border-cyan-400/50 transition-all duration-300 group">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-6 h-6 text-cyan-400" />
                </div>
                <CardTitle className="text-lg group-hover:text-cyan-400 transition-colors">
                  Automatización con Microcontroladores
                </CardTitle>
                <CardDescription className="text-gray-300">
                  Proyectos de automatización usando Arduino y sensores
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-sm mb-4">
                  Desarrollo de sistemas automatizados para optimizar procesos industriales y domésticos.
                </p>
                <div className="flex flex-wrap gap-1 mb-4">
                  <Badge variant="outline" className="border-lime-400 text-lime-400 text-xs">
                    Arduino
                  </Badge>
                  <Badge variant="outline" className="border-lime-400 text-lime-400 text-xs">
                    IoT
                  </Badge>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-gray-950 w-full bg-transparent"
                >
                  Ver Detalles
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 hover:border-lime-400/50 transition-all duration-300 group">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Globe className="w-6 h-6 text-lime-400" />
                </div>
                <CardTitle className="text-lg group-hover:text-lime-400 transition-colors">Herramientas Web</CardTitle>
                <CardDescription className="text-gray-300">
                  Aplicaciones web para optimizar flujos de trabajo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-sm mb-4">
                  Desarrollo de herramientas web personalizadas para mejorar la eficiencia organizacional.
                </p>
                <div className="flex flex-wrap gap-1 mb-4">
                  <Badge variant="outline" className="border-cyan-400 text-cyan-400 text-xs">
                    React
                  </Badge>
                  <Badge variant="outline" className="border-cyan-400 text-cyan-400 text-xs">
                    n8n
                  </Badge>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-lime-400 text-lime-400 hover:bg-lime-400 hover:text-gray-950 w-full bg-transparent"
                >
                  Ver Detalles
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 hover:border-cyan-400/50 transition-all duration-300 group">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Code className="w-6 h-6 text-cyan-400" />
                </div>
                <CardTitle className="text-lg group-hover:text-cyan-400 transition-colors">
                  Automatización de Procesos
                </CardTitle>
                <CardDescription className="text-gray-300">
                  Scripts y herramientas para automatizar tareas repetitivas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-sm mb-4">
                  Desarrollo de soluciones automatizadas usando Selenium y otras herramientas.
                </p>
                <div className="flex flex-wrap gap-1 mb-4">
                  <Badge variant="outline" className="border-lime-400 text-lime-400 text-xs">
                    Selenium
                  </Badge>
                  <Badge variant="outline" className="border-lime-400 text-lime-400 text-xs">
                    Python
                  </Badge>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-gray-950 w-full bg-transparent"
                >
                  Ver Detalles
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="habilidades" className="py-16 px-6">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="bg-gradient-to-r from-lime-400 to-cyan-400 bg-clip-text text-transparent">
              Habilidades
            </span>
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-lime-400">Tecnologías Actuales</CardTitle>
                <CardDescription>Herramientas que domino y uso regularmente</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-lime-400/20 text-lime-400 border-lime-400">HTML</Badge>
                  <Badge className="bg-lime-400/20 text-lime-400 border-lime-400">CSS</Badge>
                  <Badge className="bg-lime-400/20 text-lime-400 border-lime-400">JavaScript</Badge>
                  <Badge className="bg-lime-400/20 text-lime-400 border-lime-400">Arduino</Badge>
                  <Badge className="bg-lime-400/20 text-lime-400 border-lime-400">Microcontroladores</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-cyan-400">En Desarrollo</CardTitle>
                <CardDescription>Tecnologías que estoy aprendiendo y fortaleciendo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-cyan-400/20 text-cyan-400 border-cyan-400">Django</Badge>
                  <Badge className="bg-cyan-400/20 text-cyan-400 border-cyan-400">React</Badge>
                  <Badge className="bg-cyan-400/20 text-cyan-400 border-cyan-400">n8n</Badge>
                  <Badge className="bg-cyan-400/20 text-cyan-400 border-cyan-400">Selenium</Badge>
                  <Badge className="bg-cyan-400/20 text-cyan-400 border-cyan-400">Python</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-12 text-center">
            <h3 className="text-2xl font-semibold mb-6 text-gray-300">Áreas de Especialización</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="p-6 bg-gray-800/30 rounded-lg border border-gray-700">
                <Database className="w-12 h-12 text-lime-400 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-lime-400 mb-2">Desarrollo Web</h4>
                <p className="text-gray-300 text-sm">Creación de aplicaciones web modernas y responsivas</p>
              </div>
              <div className="p-6 bg-gray-800/30 rounded-lg border border-gray-700">
                <Zap className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-cyan-400 mb-2">Automatización</h4>
                <p className="text-gray-300 text-sm">Optimización de procesos mediante automatización</p>
              </div>
              <div className="p-6 bg-gray-800/30 rounded-lg border border-gray-700">
                <Code className="w-12 h-12 text-lime-400 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-lime-400 mb-2">Sistemas</h4>
                <p className="text-gray-300 text-sm">Desarrollo de sistemas para mejorar flujos administrativos</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contacto" className="py-16 px-6 bg-gray-900/50">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-4xl font-bold mb-8">
            <span className="bg-gradient-to-r from-lime-400 to-cyan-400 bg-clip-text text-transparent">Contacto</span>
          </h2>
          <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto">
            ¿Interesado en colaborar o conocer más sobre mi trabajo? ¡Me encantaría conectar contigo!
          </p>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <a
              href="https://linkedin.com"
              className="group p-6 bg-gray-800/50 rounded-lg border border-gray-700 hover:border-lime-400/50 transition-all duration-300"
            >
              <Linkedin className="w-12 h-12 text-lime-400 mx-auto mb-4 group-hover:scale-110 transition-transform" />
              <h3 className="text-lg font-semibold text-lime-400 mb-2">LinkedIn</h3>
              <p className="text-gray-300 text-sm">Conectemos profesionalmente</p>
            </a>

            <a
              href="https://github.com"
              className="group p-6 bg-gray-800/50 rounded-lg border border-gray-700 hover:border-cyan-400/50 transition-all duration-300"
            >
              <Github className="w-12 h-12 text-cyan-400 mx-auto mb-4 group-hover:scale-110 transition-transform" />
              <h3 className="text-lg font-semibold text-cyan-400 mb-2">GitHub</h3>
              <p className="text-gray-300 text-sm">Explora mis proyectos</p>
            </a>

            <a
              href="mailto:cristopher@email.com"
              className="group p-6 bg-gray-800/50 rounded-lg border border-gray-700 hover:border-lime-400/50 transition-all duration-300"
            >
              <Mail className="w-12 h-12 text-lime-400 mx-auto mb-4 group-hover:scale-110 transition-transform" />
              <h3 className="text-lg font-semibold text-lime-400 mb-2">Email</h3>
              <p className="text-gray-300 text-sm">Conversemos directamente</p>
            </a>
          </div>

          <div className="p-8 bg-gradient-to-r from-lime-400/10 to-cyan-400/10 rounded-lg border border-lime-400/20">
            <h3 className="text-2xl font-semibold mb-4 bg-gradient-to-r from-lime-400 to-cyan-400 bg-clip-text text-transparent">
              ¿Tienes un proyecto en mente?
            </h3>
            <p className="text-gray-300 mb-6">
              Estoy siempre abierto a nuevas oportunidades y colaboraciones interesantes.
            </p>
            <Button className="bg-gradient-to-r from-lime-400 to-cyan-400 text-gray-950 hover:from-lime-500 hover:to-cyan-500 font-semibold">
              Hablemos
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-gray-800">
        <div className="container mx-auto text-center">
          <p className="text-gray-400">
            © 2024 Cristopher Andres Rivera Concha. Creando soluciones tecnológicas para un futuro mejor.
          </p>
        </div>
      </footer>
    </div>
  )
}
